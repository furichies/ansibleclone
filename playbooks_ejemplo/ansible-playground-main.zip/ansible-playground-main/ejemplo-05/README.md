# Ejemplo 5

Este ejemplo muestra cómo instalar la pila LAMP haciendo uso de variables definidas en un archivo externo.