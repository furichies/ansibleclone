# Ejercicio 6

Este ejemplo muestra el uso de *handlers* en un playbook.