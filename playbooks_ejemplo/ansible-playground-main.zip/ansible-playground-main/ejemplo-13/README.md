# Ejemplo 13

Este ejemplo muestra dos playbooks para crear y eliminar un grupo de seguridad, una instancia EC2 y una IP elástica en AWS.