# Ejemplo 3

Este ejemplo muestra la **instalación de la pila LAMP** utilizando los módulos [`apt`][1], [`service`][2] y [`copy`][3].

[1]: https://docs.ansible.com/ansible/latest/collections/ansible/builtin/apt_module.html
[2]: https://docs.ansible.com/ansible/latest/collections/ansible/builtin/service_module.html
[3]: https://docs.ansible.com/ansible/latest/collections/ansible/builtin/copy_module.html