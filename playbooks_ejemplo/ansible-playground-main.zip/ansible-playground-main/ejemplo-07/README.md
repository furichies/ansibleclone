# Ejemplo 7

Este ejemplo muestra un playbook sobre cómo configurar MySQL Server haciendo uso de los módulos [`mysql_db`][1] y [`mysql_user`][2].

[1]: https://docs.ansible.com/ansible/2.9/modules/mysql_db_module.html
[2]: https://docs.ansible.com/ansible/latest/collections/community/mysql/mysql_user_module.html