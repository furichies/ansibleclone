# Ejemplo 9

Este ejemplo muestra cómo realizar el despliegue de una aplicación LAMP sencilla.