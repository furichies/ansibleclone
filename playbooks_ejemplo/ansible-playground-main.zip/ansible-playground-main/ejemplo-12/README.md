# Ejemplo 12

Este ejemplo muestra un  playbook para crear un grupo de seguridad y una instancia EC2 en AWS.