# Ejemplo 8

Este ejemplo muestra la cómo hacer el despliegue de phpMyAdmin.